<section id="education_section" class="d-none">
    <h2 class="text-secondary fw-bolder mb-4">Education</h2>
    <div id="education_data"></div>
</section>
