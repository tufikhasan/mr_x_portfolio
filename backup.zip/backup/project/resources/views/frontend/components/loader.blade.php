<div class="d-flex justify-content-center align-items-start d-none" id="loader">
    <img style="width:150px;" src="{{ url('upload/loader.gif') }}" />
</div>
